require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const path = require('path');


const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');

// MongoDB URI from .env
const mongoUri = 'mongodb+srv://omkolhe19:sangita%4012@addlink.r03xc.mongodb.net/mydatabase?retryWrites=true&w=majority';

mongoose.connect(mongoUri)
  .then(() => console.log('MongoDB connected successfully!'))
  .catch((err) => console.error('MongoDB connection error:', err));

app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({ mongoUrl: mongoUri }),
  cookie: { maxAge: 1000 * 60 * 60 * 24 } // 1 day
}));

const authRoutes = require('./routes/auth');
const indexRoutes = require('./routes/index');



const jwt = require('jsonwebtoken');

// Middleware to set `user` for all views if authenticated
app.use((req, res, next) => {
    const token = req.cookies['auth-token'];
    
    if (token) {
        try {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            res.locals.user = decoded; // Pass user to all views
        } catch (err) {
            console.error('Invalid token');
            res.locals.user = null; // Clear user if token is invalid
        }
    } else {
        res.locals.user = null; // No token, no user
    }
    
    next();
});






app.use('/', indexRoutes);
app.use('/auth', authRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log('Session Secret:', process.env.SESSION_SECRET);
});







